var searchData=
[
  ['calculatecoefficients_7',['calculateCoefficients',['../Segmented__Least__Squares_8cpp.html#ae83ca2e4c373a84a4854134894915bbd',1,'Segmented_Least_Squares.cpp']]]
];
