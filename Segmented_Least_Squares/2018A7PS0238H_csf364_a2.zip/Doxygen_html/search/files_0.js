var searchData=
[
  ['segmented_5fleast_5fsquares_2ecpp_6',['Segmented_Least_Squares.cpp',['../Segmented__Least__Squares_8cpp.html',1,'']]]
];
