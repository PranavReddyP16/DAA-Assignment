var searchData=
[
  ['blacken_41',['blacken',['../Contour_8cpp.html#a7081468a9dbabf996cd604feaa4c537a',1,'blacken(set&lt; Stripe &gt; S, set&lt; Interval &gt; J):&#160;Contour.cpp'],['../Measure_8cpp.html#a7081468a9dbabf996cd604feaa4c537a',1,'blacken(set&lt; Stripe &gt; S, set&lt; Interval &gt; J):&#160;Measure.cpp']]]
];
