# DAA-Assignment
Implementation of Guting's divide and conquer algorithm in C++ for finding measure and contours of a set of iso rectangles. Documentation is done using doxygen and visualisation with matplotlib
